create definer = ohgiraffers@`%` view hansik as
select `a`.`menu_code` AS `메뉴코드번호`, `a`.`menu_name` AS `메뉴명`, `b`.`category_name` AS `카테고리명`
from (`menudb`.`tbl_menu` `a` join `menudb`.`tbl_category` `b` on ((`a`.`category_code` = `b`.`category_code`)))
where (`b`.`category_name` = '한식');

-- comment on column hansik.메뉴코드번호 not supported: 메뉴코드

-- comment on column hansik.메뉴명 not supported: 메뉴명

-- comment on column hansik.카테고리명 not supported: 카테고리명

